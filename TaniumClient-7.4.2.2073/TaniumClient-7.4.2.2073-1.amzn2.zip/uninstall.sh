#!/bin/bash
cat /etc/os-release | grep fedora && yum remove -y Tanium* || apt purge -y Tanium*
