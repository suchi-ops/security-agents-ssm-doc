#!/bin/bash
dpkg -i taniumclient_7.4.2.2073-ubuntu20_amd64.deb
cp -a tanium-init.dat /opt/Tanium/TaniumClient/
/opt/Tanium/TaniumClient/TaniumClient config set ServerNameList tanium-srv-prod-a.accenture.com,tanium-srv-prod-b.accenture.com,tanium-srv-prod-z1.accenture.com,tanium-srv-prod-z2.accenture.com
/opt/Tanium/TaniumClient/TaniumClient config set LogVerbosityLevel 1
/opt/Tanium/TaniumClient/TaniumClient config set ServerPort 443
/opt/Tanium/TaniumClient/TaniumClient config set ListenPort 17472
/opt/Tanium/TaniumClient/TaniumClient config set Resolver nslookup
systemctl restart taniumclient
systemctl enable taniumclient