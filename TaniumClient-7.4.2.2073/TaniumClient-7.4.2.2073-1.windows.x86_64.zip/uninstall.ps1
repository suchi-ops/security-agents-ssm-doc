Set-ExecutionPolicy RemoteSigned
$app = Get-WmiObject -Class Win32_Product `
                     -Filter "Name = 'Tanium Client'"

$app.Uninstall()