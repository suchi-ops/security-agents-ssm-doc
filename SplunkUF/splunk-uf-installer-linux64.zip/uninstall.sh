#!/bin/bash
#!/bin/bash
tar -xf splunk-uf-installer-linux64-8.1.0.1r10.tar.gz
cd splunk-uf-installer-linux64-8.1.0.1r10
chmod +x splunkuf_nix_uninstall.sh
./splunkuf_nix_uninstall.sh
