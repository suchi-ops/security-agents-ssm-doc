Expand-Archive -Path Splunk_UF_manual_install_win.zip -DestinationPath .\
cd Splunk_UF_manual_install
msiexec /x "splunkforwarder-7.3.4.msi"