Expand-Archive -Path Splunk_UF_manual_install_win.zip -DestinationPath .\
cd Splunk_UF_manual_install
msiexec /i "splunkforwarder-7.3.4.msi"