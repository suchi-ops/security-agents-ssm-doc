cd 'C:\Program Files (x86)\Qualys'
.\Uninstall.exe CustomerId={af433332-5b18-7be7-e040-10ac130451e8} ActivationId={e7e5f786-fc2c-47f5-b394-935985e3d5d9}