#!/bin/bash
cat /etc/os-release | grep fedora && yum remove -y qualys-cloud-agent* || apt purge -y qualys-cloud-agent*
