#!/bin/bash
dpkg -i Linux_Deb_QualysCloudAgent.x86_64.deb
/usr/local/qualys/cloud-agent/bin/qualys-cloud-agent.sh ActivationId=e7e5f786-fc2c-47f5-b394-935985e3d5d9 CustomerId=af433332-5b18-7be7-e040-10ac130451e8 ProviderName=AWS